 

 <?php $__env->startSection('main'); ?>
     <div id="kelas">
         <h2>Kelas</h2>

         <?php echo $__env->make('_partial.flash_message', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

         <?php if(count($kelas_list) > 0): ?>
            <table class="table">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Kelas</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i = 0; ?>
                    <?php foreach($kelas_list as $kelas): ?>
                    <tr>
                        <td><?php echo e(++$i); ?></td>
                        <td><?php echo e($kelas->nama_kelas); ?></td>
                        <td>
                            <div class="box-button">
                                <?php echo e(link_to('kelas/' . $kelas->id . '/edit', 'Edit', ['class' => 'btn btn-warning btn-sm'])); ?>

                            </div>
                            <div class="box-button">
                                <?php echo Form::open(['method' => 'DELETE', 'action' => ['KelasController@destroy', $kelas->id]]); ?>

                                    <?php echo Form::submit('Delete', ['class' => 'btn btn-danger btn-sm']); ?>

                                <?php echo Form::close(); ?>

                            </div>
                        </td>
                    </tr>
                    <?php endforeach ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>Tidak ada data kelas.</p>
        <?php endif; ?>

        <div class="tombol-nav">
            <a href="kelas/create" class="btn btn-primary">Tambah Kelas</a>
        </div>

    </div> <!-- / #kelas -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
   <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>