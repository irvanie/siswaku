@extends('template')

@section('main')
    <div id="about">
        <h2>About</h2>
        <p>Aplikasi <strong>siswaku</strong>
        dibuat sebagai latihan untuk mempelajari Laravel.</p>
    </div>
@stop
