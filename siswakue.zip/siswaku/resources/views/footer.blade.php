<div id="footer">
    <p>&copy; 2018 siswaku.app</p>
</div>